#include <stdio.h>
#include <string.h>
#include <stdlib.h>

struct exttable {
    char cextsym[20], extsym[20];
    int address, length;
} estab[20];

struct objectcode {
    unsigned char code[15];
    int add;
} obcode[500];

void main() {
    char temp[10];
    FILE *fp1, *fp2, *fp3;
    int i, j, x, y, pstart, exeloc, start, textloc, loc, textlen, length, location, st, s;
    int n = 0, num = 0, inc = 0, count = 0, record = 0, mloc[30], mlen[30];
    signed long int newadd;
    char operation, lbl[10], INPUT_err[10], label[50][10], opr[30], ch, *add1, address[10];

    char prog_symbols[3][100][20];
    int prog_symbol_count[3] = {0, 0, 0};
    int current_prog = -1;

    fp1 = fopen("INPUT.TXT", "r");
    if (fp1 == NULL) {
        perror("Error opening INPUT_err.TXT");
        exit(1);
    }

    fp2 = fopen("ESTAB.TXT", "r");
    if (fp2 == NULL) {
        perror("Error opening ESTAB.TXT");
        fclose(fp1);
        exit(1);
    }

    fp3 = fopen("OUTPUT_err.TXT", "w");
    if (fp3 == NULL) {
        perror("Error opening OUTPUT_err.TXT");
        fclose(fp1);
        fclose(fp2);
        exit(1);
    }

    while (!feof(fp2)) {
        fscanf(fp2, "%s %s %x %x", estab[num].cextsym, estab[num].extsym, &estab[num].address, &estab[num].length);
        num++;
    }

    exeloc = estab[0].address;
    loc = exeloc;
    start = loc;
    st = start;

    while (!feof(fp1)) {
        fscanf(fp1, "%s", INPUT_err);
        if (strcmp(INPUT_err, "H") == 0) {
            fscanf(fp1, "%s", INPUT_err);
            if (strcmp(INPUT_err, "PROGA") == 0) {
                current_prog = 0;
            } else if (strcmp(INPUT_err, "PROGB") == 0) {
                current_prog = 1;
            } else if (strcmp(INPUT_err, "PROGC") == 0) {
                current_prog = 2;
            }

            while (strcmp(INPUT_err, "T") != 0)
                fscanf(fp1, "%s", INPUT_err);
        }

        do {
            if (strcmp(INPUT_err, "T") == 0) {
                fscanf(fp1, "%x", &textloc);
                textloc = textloc + pstart;
                for (i = 0; i < (textloc - loc); i++) {
                    strcpy(obcode[inc].code, "..");
                    obcode[inc++].add = start++;
                }
                fscanf(fp1, "%x", &textlen);
                loc = textloc + textlen;
            }
            else if (strcmp(INPUT_err, "M") == 0) {
                fscanf(fp1, "%x", &mloc[record]);
                mloc[record] = mloc[record] + pstart;
                fscanf(fp1, "%x", &mlen[record]);
                fscanf(fp1, "%s", label[record++]);

                strcpy(prog_symbols[current_prog][prog_symbol_count[current_prog]++], label[record - 1]);
            }
            else {
                length = strlen(INPUT_err);
                x = 0;
                for (i = 0; i < length; i++) {
                    obcode[inc].code[x++] = INPUT_err[i];
                    if (x > 1) {
                        obcode[inc++].add = start++;
                        x = 0;
                    }
                }
            }
            fscanf(fp1, "%s", INPUT_err);
        } while (strcmp(INPUT_err, "E") != 0);

        if (strcmp(INPUT_err, "E") == 0)
            fscanf(fp1, "%s", INPUT_err);
    }

    // Print Defined Symbols
   /* printf("\nDefined Symbols:\n");
    for (i = 0; i < num; i++) {
        printf("%d %s %s\n", i, estab[i].cextsym, estab[i].extsym);
    }*/

    printf("\nExternal Referenced Symbols mapped to Programs:\n");
    for (i = 0; i < 3; i++) {
        printf("\nProgram %s:\n", (i == 0) ? "PROGA" : (i == 1) ? "PROGB" : "PROGC");
        for (j = 0; j < prog_symbol_count[i]; j++) {
            printf("%d %s\n", j + 1, prog_symbols[i][j]);
        }
    }

    fclose(fp1);
    fclose(fp2);
    fclose(fp3);

   printf("\n\t***** PASS TWO OF A DIRECT-LINKING LOADER *****\n");
    printf("\nThe contents of the output file:");
    printf("\n---------------------------------------------------------------");
    printf("\nAddress\t\t\t\tContents");
    printf("\n---------------------------------------------------------------\n");

    fp3 = fopen("OUTPUT.TXT", "r");
    ch = fgetc(fp3);
    while (ch != EOF)
    {
        printf("%c", ch);
        ch = fgetc(fp3);
    }
    fclose(fp3);
}
